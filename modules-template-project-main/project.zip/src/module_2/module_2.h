#ifndef MODULE1_H
#define MODULE1_H

#include "../main.h"

#define FIBNUM 4 // A number to use in real program (not for testing)

int fib(int n);

#endif
 