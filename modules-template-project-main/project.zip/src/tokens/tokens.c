/*
 * -----------------------------------------------------------------------------
 * tokens.c
 *
 * Module: tokens - Tokenization/Lexer
 * Responsible for: Breaking source code into tokens for processing
 *
 * Author: [Team Member 7]
 * -----------------------------------------------------------------------------
 */

#include "tokens.h"

void tokens_init(void) {
    fprintf(ofile, "[tokens] OK\n");
}
