#ifndef PP_SPEC_H
#define PP_SPEC_H

#define PP_MAX_IF_DEPTH 64

#define PP_FLAG_C    "-c"
#define PP_FLAG_D    "-d"
#define PP_FLAG_ALL  "-all"
#define PP_FLAG_HELP "-help"

#endif
